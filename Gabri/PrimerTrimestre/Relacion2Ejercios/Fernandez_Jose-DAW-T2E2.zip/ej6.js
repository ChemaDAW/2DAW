function ej6() {
    var clave1 = (prompt("Dime la primera clave"));
    var clave2 = (prompt("Dime la segunda clave"));
    if(clave1==clave2){
        alert("Las claves son iguales");
    }else{
        alert("Las claves no son iguales")
    }
}