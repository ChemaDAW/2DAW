function ej5() {
    var a, b;
    a = prompt("Escribe la base:");
    b = prompt("Escribe la altura:");
    alert("Área= " + (a * b / 2));
}