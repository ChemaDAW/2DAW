<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Ejercicio 6</title>
</head>
<body>
	<?php 
		$numero=10;
		printf("El numero $numero en binario %b y en decimal %o",$numero,$numero);
	 ?>
</body>
</html>