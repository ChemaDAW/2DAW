<?php
function ej4($titulo) {
    echo "<!DOCTYPE html>";
    echo "<html lang='es'>";
    echo "<head>";
    echo "<meta charset='UTF-8'>";
    echo "<meta name='viewport' content='width=device-width, initial-scale=1.0'>";
    echo "<title>$titulo</title>";
    echo "</head>";
    echo "<body>";
}

// Ejemplo de uso
ej4("hotel chema");
?>
