<?php
function ej6($texto) {
    return "<strong>$texto</strong>";
}

// Ejemplo de uso
echo ej6("hola soy chema");
?>
