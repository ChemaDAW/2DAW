<?php
function cuadrado($num){
    echo $num*$num."\n";
}
function cubo($num){
    echo $num*$num*$num;
}

$num=7;
cuadrado($num);
cubo($num);
?>
