<?php
function ej5($num1,$num2){
    return ($num1 + $num2)/2;
}
$num1=5;
$num2= 10;
echo $semisuma=ej5($num1,$num2);
?>
