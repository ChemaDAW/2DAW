import java.util.*;

public class Basicos_Ej9 {
    static Scanner teclado = new Scanner(System.in);

    public static void main(String[] args) {
        // Creacion de variables
        int p = 10, q = 5;
        char a = 'a', b = 'b', c = 'c';
        long contador = 10000;
        int indice = 10;
        char car1 = '1', car2 = '2';
        boolean primero = true, ultimo = false;
        float x = 1.0, y = 2.0, z = 3.0;
        double raiz1 = 14.3, raiz2 = 3.14;
        short indicador = 1;
        double precio = 100, precioFinal = 120;
        byte valor = 0;
        String nombre = "Chema";
    }
}
