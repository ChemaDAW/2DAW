import java.util.*;

public class Basicos_Ej7 {
    static Scanner teclado = new Scanner(System.in);

    public static void main(String[] args) {
        // Creacion de variables
        // Codigo del programa
        for (int i = 100; i >= 0; i = i - 7) {
            System.out.println(i);
        }
    }

}