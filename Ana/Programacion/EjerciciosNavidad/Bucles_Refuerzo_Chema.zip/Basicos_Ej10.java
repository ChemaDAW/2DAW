import java.util.*;

public class Basicos_Ej10 {
    static Scanner teclado = new Scanner(System.in);

    public static void main(String[] args) {
        // Creacion de variables
        byte edad = 19;
        float altura = 1.70;
        String nombre = "Chema";
        byte iva = 21;
        boolean alumnoRepetidor = true;
        char letra = 'f';
        byte minutos = 59;
        String matriculCoche = "413242132M";
        boolean mayorDeEdad = true;
        int codigoPostal = 04700;
        char genero = 'h';
        byte numerosDeHijos = 0;
        byte tallaCamisa = 30;
        long precio = 321321;
        String mensaje = "Hola,buenas";
        byte mayorEdad = 18;
        short dias = 365;
        int contador = 10;
        String tallaCamiseta = "XL";
    }
}
