package Animales;

import java.util.*;

public class PrincipalAnimales {
    public static void main(String[] args) {  
        Mamiferos Chema=new Mamiferos();
        Mamiferos chema2=new Mamiferos(Chema);      
    }
}
