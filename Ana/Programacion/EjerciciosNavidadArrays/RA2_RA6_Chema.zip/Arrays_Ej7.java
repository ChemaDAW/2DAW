public class Arrays_Ej7 {

}
